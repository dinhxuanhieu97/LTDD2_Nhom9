package vn.edu.tdc.listnhac;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class MusicActivity extends AppCompatActivity {

    ListView lvNhac;
    RelativeLayout mh;
    MediaPlayer song;

    ArrayList<String> mangTenBH;
    ArrayList<Integer> mangMp3;

    public void AnhXa(){
        lvNhac  = (ListView) findViewById(R.id.lvNhac);
        mh = (RelativeLayout) findViewById(R.id.manHinh);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        //Ánh xạ
        AnhXa();

        //Play nhạc nền
        song = MediaPlayer.create(getApplicationContext(), R.raw.suthatsaumotloihua);
        song.start();

        //Tạo mảng
        TaoMang();

        //listview
        ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, mangTenBH);
        lvNhac.setAdapter(adapter);

        //listview onitemclick
        lvNhac.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                song = MediaPlayer.create(getApplicationContext(), mangMp3.get(position));
                song.start();
            }
        });


    }

    public void TaoMang(){
        mangTenBH = new ArrayList<String>();
        mangMp3 = new ArrayList<Integer>();

        mangMp3.add(R.raw.coduockhongem);
        mangTenBH.add("Có được không em");

        mangMp3.add(R.raw.giacmoemcho);
        mangTenBH.add("Giấc mơ em cho");

        mangMp3.add(R.raw.suthatsaumotloihua);
        mangTenBH.add("Sự thật sau một lời hứa");

    }
}
