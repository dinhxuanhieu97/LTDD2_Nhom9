package vn.edu.tdc.listnhac;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    RelativeLayout mh;
    ImageView imgIcon;

    public void AnhXa(){
        mh = (RelativeLayout) findViewById(R.id.manHinh);
        imgIcon = (ImageView) findViewById(R.id.imgIcon);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AnhXa();

        //hieu ung hinh
        Animation f = AnimationUtils.loadAnimation(this, R.anim.fade);
        f.reset();
        imgIcon.clearAnimation();
        imgIcon.startAnimation(f);

        imgIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mhMusic = new Intent(getApplicationContext(), MusicActivity.class);
                startActivity(mhMusic);
            }
        });

    }
}
