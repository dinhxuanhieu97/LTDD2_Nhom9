package vn.edu.tdc.myanimation;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;

import com.yasic.library.particletextview.MovingStrategy.BidiHorizontalStrategy;
import com.yasic.library.particletextview.Object.ParticleTextViewConfig;
import com.yasic.library.particletextview.View.ParticleTextView;

public class MainActivity extends AppCompatActivity {

    ParticleTextView p1, p2;
    ImageView imageView;
    Button btnStart, btnStop;
    AnimationDrawable animation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //animation for text
        p1 = (ParticleTextView) findViewById(R.id.one);
        ParticleTextViewConfig c1 = new ParticleTextViewConfig.Builder()
                .setTargetText("Ngoc Hien")
                .setReleasing(0.4)
                .setMiniDistance(2)
                .setTextSize(150)
                .setRowStep(9)
                .setColumnStep(9)
                .instance();
        p1.setConfig(c1);

        p2 = (ParticleTextView) findViewById(R.id.two);
        BidiHorizontalStrategy mov = new BidiHorizontalStrategy();
        ParticleTextViewConfig c2 = new ParticleTextViewConfig.Builder()
                .setTargetText("Animation")
                .setReleasing(0.3)
                .setParticleRadius(4)
                .setMiniDistance(0.01)
                .setTextSize(100)
                .setRowStep(8)
                .setColumnStep(8)
                .setMovingStrategy(mov)
                .instance();
        p2.setConfig(c2);

        p1.startAnimation();
        p2.startAnimation();

        //animation for flower
        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        imageView = (ImageView) findViewById(R.id.img);

        if (imageView==null) throw  new AssertionError();
        imageView.setBackgroundResource(R.drawable.anim);
        imageView.setVisibility(View.INVISIBLE);
        animation = (AnimationDrawable)imageView.getBackground();

        //xử lí sự kiện cho button
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setVisibility(View.VISIBLE);
                if (animation.isRunning())
                    animation.stop();
                animation.start();

            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animation.stop();
            }
        });

    }
}
